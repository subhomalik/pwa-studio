export { default } from './forgotPassword';
