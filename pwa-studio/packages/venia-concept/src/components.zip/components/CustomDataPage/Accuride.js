import React from 'react'

const Accuride = ({ contacts }) => {
    return (
        <div>
            <center><h1>Contact List</h1></center>
            {contacts.map((contact2) =>

                <p key={contact2.id}>{contact2.name}</p>
            )}
        </div>
    )
};

export default Accuride