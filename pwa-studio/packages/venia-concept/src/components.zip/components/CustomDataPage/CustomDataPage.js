import React, { Component, Fragment } from 'react';
import { withRouter } from 'react-router-dom';
import { compose } from 'redux';
import classify from 'src/classify';
import Accuride from './Accuride';

class CustomDataPage extends Component {

    //let dddddd = this.componentDidMount();
    render() {
        return (
            <Accuride contacts={this.state.contacts} />
        );
    }


    state = {
        contacts: []
    };
    componentDidMount() {
        fetch('https://staging.blog.accuride.com/wp-json/wp/v2/posts ')
            .then(res => res.json())
            .then((data) => {
                this.setState({ contacts: data })
            })
            .catch(console.log);
        //console.log(contacts);
    }
}


export default compose(
    withRouter
)(CustomDataPage);