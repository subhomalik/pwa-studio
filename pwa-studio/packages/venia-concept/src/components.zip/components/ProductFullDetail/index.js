export { default as ProductFullDetail } from './ProductFullDetail';
export { default } from './container';
