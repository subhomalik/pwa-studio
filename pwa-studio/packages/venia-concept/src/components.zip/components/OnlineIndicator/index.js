export { default } from './onlineIndicator';
