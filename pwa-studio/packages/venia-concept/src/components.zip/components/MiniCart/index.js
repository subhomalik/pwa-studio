export { default } from './miniCart';
