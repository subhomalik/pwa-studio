export { default } from './purchaseDetailsContainer';
