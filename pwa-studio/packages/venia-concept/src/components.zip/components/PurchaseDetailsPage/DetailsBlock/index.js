export { default } from './detailsBlock';
