export { default } from './PurchaseDetails';
