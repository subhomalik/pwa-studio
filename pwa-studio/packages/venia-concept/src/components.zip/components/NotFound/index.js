export { default } from './notFound';
