export { default } from './richText';
