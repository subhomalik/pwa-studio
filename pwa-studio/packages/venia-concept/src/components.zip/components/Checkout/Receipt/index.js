export { default } from './receiptContainer';
